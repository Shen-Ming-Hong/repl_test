'''
你在測試以下程式碼時發現錯誤。其中包含的行號只是做為參考。

01 numList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
02 i = 0
03 while (i < 10)
04  print(numList[i])
05
06  if numList(i) = 6
07      break
08  else:
09      i += 1

你需要更正03行和06行中的程式碼。你要如何更正程式碼?
(1)在03行中應使用哪個程式碼片段?
A. while (i < 10) :
B. while [i < 10]
C. while (i < 5) :
D. while [i < 5]
(2)在06行中應使用哪個程式碼片段?
A. if numList[i] == 6
B. if numList[i] == 6 :
C. if numList(i) = 6 :
D. if numList(i) != 6
'''
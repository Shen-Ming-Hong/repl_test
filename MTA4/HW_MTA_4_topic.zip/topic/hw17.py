'''
你設計程式碼用來生成的隨機整數,最小值為11,最大值為20
你應該使用哪兩種函式?

( )A. random.randrange(11, 21, 1)
( )B. random.randrange(11, 20, 1)
( )C. random.randint(11, 20)
( )D. random.randint(11, 21)
'''
'''
你設計程式碼用來生成的隨機整數,最小值是0,最大值是10
你應該使用哪個語法?
( )A. random.random()
( )B. random.randrange(0.0, 1.0)
( )C. random.randrange()
( )D. random.randint(0, 10)
'''
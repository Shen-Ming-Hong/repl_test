'''
你正在設計Python應用程式。程式將逐一查看數字清單,
並在找到4時進行跳脫的動作。
你要如何完成這段程式碼?請在回答區選擇適當的程式碼片段。

nList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
index = 0
__(1)__(index < 10) :
print(nList[index])
if nList[index] == 4 :
    __(2)__
else:
    __(3)__

( )(1) 
A. while 
B. for
c, if
D. break
( )(2) 
A. while
B. for 
C. if
D. break
( )(3) 
A. continue 
B. break 
C. index += 1 
D. index = 1

'''
'''
你設計了一個Python程式查英文姓名的大小寫,
請將下方的程式碼ABCDEF排列出正確的執行順序
A.
name = input("輸入你的英文灶名:")
B.
elif name.lower() == name:
    print(name, "是全部小寫.")
C.
else:
    print(name, "是大寫.")
D.
else:
    print(name, "是大小寫混合.")
E. 
if name.upper() == name:
    print(name, "是全部大寫.")
F.
else:
    print(name, "是小寫.")
'''
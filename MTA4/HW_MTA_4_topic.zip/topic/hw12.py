'''
公司決定要幫所有年薪不到50萬的員工調升基本薪資5%,並給予獎金1萬元,
以下是計算公式:
新工資 = 日前工資 X 105% + $10000獎金
程式會將每個人調整後的薪資料存入 salarylist 清單中。
你要如何完成這段程式碼?請在回答區選擇適當的程式碼片段。

#清單中的每個人的工資都根據增加而更新。
#年薪50萬元以上的員工將不會得到加薪。
#salarylist是由員工資料庫中取得,程式碼不會顯示

__(1)__
    if salaryListlindex] >= 150000:
        __(2)__
    salaryList[index] = (salaryList[index] * 1.05) +10000



( )(1)  
A. for index in range(len(salary_list)+1):
B. for index in range(len(salary_1ist)-1):
C. for index in range(len(salary_list)):
D. for index in salary_list:
( )(2) 
A. exit()
B. continue
C. break
D. end
'''
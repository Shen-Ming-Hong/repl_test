'''
你設計程式碼來產生一個隨機數來符合以下要求:
.數字是2的倍數。
.最低的數字是2。
.最高的數字是50。
哪兩個程式碼片段將符合要求?
( )A. 
from random import randint
print(randint(1, 25) * 2)
( )B. 
from random import randint
print(randint(1, 50))
( )C. 
from random import randrange
print(randrange(2, 50, 2))
( )D. 
from random import randrange
print(randrange(2, 50, 1))
'''
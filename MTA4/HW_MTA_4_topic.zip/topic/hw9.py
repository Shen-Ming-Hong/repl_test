'''
在程式中要使用datetime模組中 datetime 函式, 再設定dt為替代名稱，
在導入時應該使用哪個程式碼片段?
( )A. from datetime as dt
( )B. from datetime import datetime as dt
( )C. import datetime from datetime as dt
( )D. import datetime.datetime as dt
'''
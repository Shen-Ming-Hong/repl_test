'''
20.老閱要求你對以下程式碼除錯:

x=0
while x < 4:
    if x % 4 == 0:
        print("party")
    elif x - 2 < 0:
        print("cake")
    elif x / 3 == 0:
        print("greeting")
    else:
        print("birthday")
    x = x + 1

什麼將會輸出列印到螢幕上?
( )A.
party
greeting
birthday
cake
()B.
party
cake
birthday
birthday
( )C.
birthday
party
greeting
cake
( )D.
birthday
greeting
party
cake
'''
